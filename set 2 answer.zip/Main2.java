/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 6student107
 */

class invalideValue extends Exception{
    public invalideValue(String msg){
        super(msg);
    }
}

class Circle{
    double radius;
    public Circle(double radius) throws invalideValue{
        if(radius<0){
            this.radius=0;
            throw new invalideValue("not valid radius");
        }
        this.radius=radius;
    }   
    public double getRadius(){
        return radius;
    }
    public double getArea(){
        double PI = Math.PI;
        return (radius*radius*PI);
    }
}

class Cylinder extends Circle{
    
    double height;
    public Cylinder(double radius,double height) throws invalideValue{
        super(radius);
        if (height < 0) {
            this.height = 0;
        } else {
            this.height = height;
        }
    }
    Circle c = new  Circle(radius);
    public double getHeight(){
        return height;
    }
    public double getVolume(){
        return c.getArea()*height;
    }
}

public class Main2 {
    public static void main(String[] args) {
        try{
            Cylinder c = new Cylinder(-5, 5);
            double Volume = c.getVolume();
            System.out.println(Volume);
        }
        catch(invalideValue e){
            System.out.println(e.getMessage());
        }
    }
}
